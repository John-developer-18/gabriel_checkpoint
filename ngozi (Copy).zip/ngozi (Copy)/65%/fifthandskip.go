package main

func FifthAndSkip(str string) string {
	if len(str) == 0 {
		return "\n"
	}

	// Remove spaces for counting
	cleaned := []rune{}
	for _, r := range str {
		if r != ' ' {
			cleaned = append(cleaned, r)
		}
	}

	if len(cleaned) < 5 {
		return "Invalid Input\n"
	}

	result := []rune{}
	for i := 0; i < len(cleaned); {
		// Take 5 characters
		end := i + 5
		if end > len(cleaned) {
			end = len(cleaned)
		}
		result = append(result, cleaned[i:end]...)
		i = end
		// Skip the 6th character if exists
		i++
		// Add space if more characters remain
		if i < len(cleaned) {
			result = append(result, ' ')
		}
	}

	return string(result)
}
