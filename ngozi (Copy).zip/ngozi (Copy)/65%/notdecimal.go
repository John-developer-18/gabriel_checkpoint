package main

func Atoi(str string) int {

	num := 0
	isNeg := false
	start := 0

	if str[0] == '-' {
		isNeg = true
		start = 1
	}

	for i := start; i < len(str); i++ {
		c := str[i]

		num = num*10 + int(c-'0')
	}
	if isNeg {
		num = -num
	}
	return num
}

func NotDecimal(str string) string {

	result := ""

	

	for i := 0; i < len(str); i++ {

		if str[i] != '.' && !(str[i] >= 'a' && str[i] <= 'z') && !(str[i] >= 'A' && str[i] <= 'Z') {
			result += string(str[i])
		}

	}
	return result
}
