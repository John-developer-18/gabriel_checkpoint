package main

func RevConcatAlternate(slice1, slice2 []int) []int {
	i := len(slice1) - 1
	j := len(slice2) - 1
	result := []int{}

	// Determine which slice is longer
	for i >= 0 || j >= 0 {
		if i >= j {
			if i >= 0 {
				result = append(result, slice1[i])
				i--
			}
			if j >= 0 {
				result = append(result, slice2[j])
				j--
			}
		} else {
			if j >= 0 {
				result = append(result, slice2[j])
				j--
			}
			if i >= 0 {
				result = append(result, slice1[i])
				i--
			}
		}
	}

	return result
}
