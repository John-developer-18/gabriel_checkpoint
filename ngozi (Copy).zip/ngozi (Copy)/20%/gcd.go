package main

// Gcd computes the greatest common divisor (GCD) of two unsigned integers a and b.
// If either a or b is zero, it returns 0.
func Gcd(a, b uint) uint {
	if a == 0 || b == 0 {
		return 0
	}

	for b != 0 {
		a, b = b, a%b
	}
	return a
}
