package main

func RepeatAlpha(s string) string {
	if s == "" {
		return ""
	}
	result := ""

	for _, c := range s {
		repeat := 0

		if c >= 'A' && c <= 'Z' {
			repeat += int(c - 'A' + 1)
		}
		if c >= 'a' && c <= 'z' {
			repeat += int(c - 'a' + 1)
		}

		for i := 0; i < repeat; i++ {
			result += string(c)
		}
	}
	return result
}
