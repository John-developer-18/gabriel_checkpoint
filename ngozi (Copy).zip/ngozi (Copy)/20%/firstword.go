package main

func FirstWord(s string) string {
	// Skip leading spaces
	start := 0
	for start < len(s) && s[start] == ' ' {
		start++
	}

	// Find the end of the first word
	end := start
	for end < len(s) && s[end] != ' ' {
		end++
	}

	return s[start:end] + "\n"
}
