package main

// DigitLen returns the number of digits required to represent the integer n in the given base.
// Parameters:
//
//	n: the integer to be represented
//	base: the base (between 2 and 36)
//
// Returns:
//
//	The number of digits in n for the specified base, or -1 if the base is invalid.
func DigitLen(n, base int) int {
	if base < 2 || base > 36 {
		return -1
	}
	if n < 0 {
		n = -n
	}

	num := 0

	for n > 0 {
		n = n / base

		num++
	}
	return num
}
