package main

func CamelToSnakeCase(s string) string {

	if s == "" {
		return ""
	}

	l := len(s)

	if s[l-1] >= 'A' && s[l-1] <= 'Z' { //We check if the end of the string is a capital letter
		return s
	}

	result := ""

	for i, c := range s {

		if (c >= 'A' && c <= 'Z') && (s[i+1] >= 'A' && s[i+1] <= 'Z') { //This checks for trailing 0s
			return s
		}

		if i != 0 && (c >= 'A' && c <= 'Z') { //Adds _ if we reach a point there is a capital letter and it is not at the start of the word
			result += "_"
		}

		result += string(c) //Appends the remainder
	}
	return result
}
