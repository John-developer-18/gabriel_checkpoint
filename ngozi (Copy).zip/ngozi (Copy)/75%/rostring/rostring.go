package main

import (
	"fmt"
	"os"
)

func main() {
	args := os.Args[1:]

	if len(args) != 1 {
		return
	}

	input := args[0]

	rostring := Field(input)

	var empty []string

	for i := 1; i <= len(rostring)-1; i++ {
		empty = append(empty, rostring[i])
	}

	empty = append(empty, rostring[0])

	fmt.Println(Join(empty, " "))
}

func Field(str string) []string {
	var fields []string

	n := len(str)

	i := 0

	for i < n {
		// Skip leading whitespace
		for i < n && (str[i] == ' ' || str[i] == '\t' || str[i] == '\n') {
			i++
		}

		if i >= n {
			break
		}

		start := i

		for i < n && !(str[i] == ' ' || str[i] == '\t' || str[i] == '\n') {
			i++
		}

		fields = append(fields, str[start:i])

	}
	return fields
}

func Join(str []string, sep string) string {

	result := str[0]

	for i := 1; i < len(str); i++ {
		result = result + sep + str[i]
	}
	return result
}
