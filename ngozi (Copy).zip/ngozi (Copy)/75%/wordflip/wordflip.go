package main

import (
	"fmt"
	"os"
)

func Field(str string) []string {
	var fields []string
	n := len(str)
	i := 0

	for i < n {
		for i < n && (str[i] == ' ' || str[i] == '\n' || str[i] == '\t') {
			i++
		}

		if i >= n {
			break
		}

		start := i

		for i < n && !(str[i] == ' ' || str[i] == '\n' || str[i] == '\t') {
			i++
		}

		fields = append(fields, str[start:i])
	}
	return fields
}

func Join(str []string, sep string) string {
	result := str[0]

	for i := 1; i < len(str); i++ {
		result = result + sep + str[i]
	}

	return result
}

func main() {
	args := os.Args[1:]

	if len(args) != 1 {
		return
	}

	input := args[0]

	words := Field(input)

	var reverse []string

	for i := len(words) - 1; i >= 0; i-- {
		reverse = append(reverse, words[i])
	}

	fmt.Println(Join(reverse, " "))

}
