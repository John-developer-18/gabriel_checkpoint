package main

import (
	"fmt"
	"os"
	"strings"
)

func main() {
	args := os.Args[1:]

	if len(args) != 1 {
		return
	}

	input := args[0]

	splited := strings.Fields(input)

	var reversed []string

	for i := len(splited) - 1; i >= 0; i-- {
		reversed = append(reversed, splited[i])
	}

	fmt.Println(strings.Join(reversed, " "))

}
