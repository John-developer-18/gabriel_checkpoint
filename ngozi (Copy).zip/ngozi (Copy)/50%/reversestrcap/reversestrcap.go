package main

import (
	"fmt"
	"os"
)

func main() {
	if len(os.Args) < 2 {
		return
	}

	for _, arg := range os.Args[1:] {
		i := 0
		for i < len(arg) {
			start := i
			// Find end of word
			for i < len(arg) && arg[i] != ' ' {
				i++
			}
			end := i - 1
			// Print word with last letter uppercase, rest lowercase
			for j := start; j <= end; j++ {
				c := arg[j]
				if j == end && c >= 'a' && c <= 'z' {
					c -= 32 // lowercase → uppercase
				} else if j != end && c >= 'A' && c <= 'Z' {
					c += 32 // uppercase → lowercase
				}
				fmt.Print(string(c))
			}
			// Print space(s) after word
			for i < len(arg) && arg[i] == ' ' {
				fmt.Print(string(arg[i]))
				i++
			}
		}
		fmt.Print(" ")
	}
	fmt.Println()
}
