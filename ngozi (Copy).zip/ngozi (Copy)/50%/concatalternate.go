package main

func ConcatAlternate(s1, s2 []int) []int {
	var concat []int
	var first []int
	var second []int
	max := len(s1)
	first = s1
	second = s2

	if len(s2) > len(s1) {
		max = len(s2)
		first = s2
		second = s1
	}

	for i := 0; i < max; i++ {
		concat = append(concat, first[i])

		if i <= len(second)-1 {
			concat = append(concat, second[i])
		}
	}

	return concat
}
