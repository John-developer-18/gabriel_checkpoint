package main

func CanJump(nums []uint) bool {
	l := len(nums) 
	if l == 0 {
		return false 
	}

	if l == 1 {
		return true
	}
	pos := 0

	for {
		step := nums[pos]

		if step == 0 {
			return false
		}

		next := pos + int(step)

		if next > l-1 {
			return false
		}

		if next == l-1 {
			return true
		}

		pos = next
	}
}

//first I need a counter that updated pos 
//i need to get the steps inside the for loop
//if the step is 0 I need to return false
//I need to get the next position by pos+step
//I need to check the next position if it is safe
//I need to check if it is greater than the lenght
//if 
