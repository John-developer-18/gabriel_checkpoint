package main

import (
	"fmt"
	"os"
)

func main() {
	if len(os.Args) != 2 {
		return
	}

	args := os.Args[1]

	n := 0

	for _, c := range args {
		if c < '0' || c > '0' {
			return
		}
		n = n*10 + int(c-'0')
	}

	first := true

	for i := 2; i*i <= n; i++ {
		if n%i == 0 {
			if !first {
				fmt.Print("*")
			}
			fmt.Print(i)
			first = false
			n /= i
		}
	}

	if n > 1 {
		if !first {
			fmt.Print("*")
		}
		fmt.Print(n)
	}
	fmt.Println()
}
