package main

import (
	"fmt"
	"os"
)

func main() {
	if len(os.Args) != 3 {
		return
	}

	s1 := os.Args[1]
	s2 := os.Args[2]

	printed := make(map[rune]bool)

	for _, c1 := range s1 {
		if !printed[c1] {
			for _, c2 := range s2 {
				if c1 == c2 {
					fmt.Print(string(c1))
					printed[c1] = true
					break
				}
			}
		}
	}
	fmt.Println()
}
