package main

import (
	"fmt"
	"os"
)

func main() {
	if len(os.Args) != 3 {
		return
	}

	s1 := os.Args[1]
	s2 := os.Args[2]

	if canWrite(s1, s2) {
		fmt.Println(s1)
	}
}

func canWrite(s1, s2 string) bool {
	if len(s1) == 0 {
		return true
	}

	j := 0
	for i := 0; i < len(s2); i++ {
		if s2[i] == s1[j] {
			j++
			if j == len(s1) {
				return true
			}
		}
	}
	return false
}
