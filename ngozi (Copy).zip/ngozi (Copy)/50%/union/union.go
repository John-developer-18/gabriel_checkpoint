package main

import (
	"fmt"
	"os"
)

func main() {
	if len(os.Args) != 3 {
		fmt.Println()
		return
	}

	s1 := os.Args[1]
	s2 := os.Args[2]

	printed := make(map[byte]bool)

	for i := 0; i < len(s1); i++ {
		c := s1[i]
		if !printed[c] {
			fmt.Printf("%c", c)
			printed[c] = true
		}
	}

	for i := 0; i < len(s2); i++ {
		c := s2[i]
		if !printed[c] {
			fmt.Printf("%c", c)
			printed[c] = true
		}
	}

	fmt.Println()
}
