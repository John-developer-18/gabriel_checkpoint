package main

import "github.com/01-edu/z01"

func PrintMemory(arr [10]byte) {
	for i := 0; i < 10; i += 5 {
		for j := i; j < i+5 && j < 10; j++ {
			printHex(arr[j])
			z01.PrintRune(' ')
		}
		z01.PrintRune('\n')
	}

	for i := 0; i < 10; i++ {
		b := arr[i]
		if b >= 32 && b <= 126 {
			z01.PrintRune(rune(b))
		} else {
			z01.PrintRune('.')
		}
	}
	z01.PrintRune('\n')
}

// Converts a byte to two hexadecimal characters using only z01.PrintRune
func printHex(b byte) {
	high := b >> 4  // top nibble
	low := b & 0x0F // bottom nibble
	z01.PrintRune(hexDigit(high))
	z01.PrintRune(hexDigit(low))
}

// Convert a number (0–15) into a hex rune ('0'–'9', 'a'–'f')
func hexDigit(n byte) rune {
	if n < 10 {
		return rune('0' + n)
	}
	return rune('a' + (n - 10))
}
