package main

func ZipString(str string) string {
	if str == "" {
		return ""
	}

	result := ""
	count := 1

	for i := 0; i < len(str); i++ {
		if i+1 < len(str) && str[i] == str[i+1] {
			count++
		} else {
			result += string('0'+rune(count)) + string(str[i])
		}

	}
	return result
}
