package main

func FindPrevPrime(n int) int {
	if n < 2 {
		return 0
	}

	for i := n; i >= 2; i-- {
		isprime := true
		for j := 2; j*j <= i; j++ {
			if i%j == 0 {
				isprime = false
				break
			}
		}
		if isprime {
			return i
		}

	}
	return 0
}

//Take note of not incrmenting when you should decrement
