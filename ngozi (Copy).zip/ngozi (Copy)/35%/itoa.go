package main

func Itoa(n int) string {
	// Handle zero
	if n == 0 {
		return "0"
	}

	sign := ""
	if n < 0 {
		sign = "-"
		n = -n
	}

	result := ""

	// Build the string from the back
	for n > 0 {
		digit := n % 10
		result = string('0'+rune(digit)) + result // prepend digit
		n /= 10
	}

	return sign + result
}
