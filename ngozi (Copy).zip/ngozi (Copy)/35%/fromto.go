package main

func FromTo(from, to int) string {
	if from < 0 || from > 99 || to < 0 || to > 99 {
		return "Invalid\n"
	}

	step := 1

	if from > to {
		step = -1
	}

	result := ""

	for i := from; ; i += step {

		if i < 10 {
			result += "0"
			result += string('0' + rune(i))
		} else {
			result += string('0' + rune(i/10))
			result += string('0' + rune(i%10))

		}

		if i == to {
			break
		}
		result += ", "
	}
	return result + "\n"
}
