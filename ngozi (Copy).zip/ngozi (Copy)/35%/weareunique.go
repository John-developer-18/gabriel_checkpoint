package main

func WeAreUnique(str1, str2 string) int {
	if str1 == "" && str2 == "" {
		return -1
	}

	var A, B [128]bool

	count := 0

	for _, c := range str1 {
		if c < 128 {
			A[c] = true
		}
	}

	for _, c := range str2 {
		if c < 128 {
			B[c] = true
		}
	}

	for i := 0; i < 128; i++ {
		if A[i] != B[i] {
			count++
		}
	}
	return count
}
