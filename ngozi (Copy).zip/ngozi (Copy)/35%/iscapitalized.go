package main

func IsCapitalized(s string) bool {
	if s == "" {
		return false
	}

	startOfWord := true // true at the beginning of the string or after a space

	for _, r := range s {
		if startOfWord {
			if r >= 'a' && r <= 'z' {
				return false
			}
			// word is valid if first char is uppercase or non-alphabetic
			startOfWord = false
		}

		// After a space, next character is the start of a new word
		if r == ' ' {
			startOfWord = true
		}
	}

	return true
}
